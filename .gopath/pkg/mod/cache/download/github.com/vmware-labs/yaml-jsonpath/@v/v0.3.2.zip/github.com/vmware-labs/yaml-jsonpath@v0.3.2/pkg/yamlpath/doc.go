/*
 * Copyright 2020 VMware, Inc.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

// Package yamlpath provides YAML node searching using path notation.
package yamlpath
