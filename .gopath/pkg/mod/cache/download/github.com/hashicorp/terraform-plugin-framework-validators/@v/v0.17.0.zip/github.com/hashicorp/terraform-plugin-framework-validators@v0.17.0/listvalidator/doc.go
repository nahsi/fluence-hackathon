// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

// Package listvalidator provides validators for types.List attributes and function parameters.
package listvalidator
