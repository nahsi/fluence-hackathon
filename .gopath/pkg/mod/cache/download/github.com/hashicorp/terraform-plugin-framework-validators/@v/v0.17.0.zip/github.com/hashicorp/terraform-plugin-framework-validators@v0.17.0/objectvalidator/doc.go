// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

// Package objectvalidator provides validators for types.Object attributes.
package objectvalidator
