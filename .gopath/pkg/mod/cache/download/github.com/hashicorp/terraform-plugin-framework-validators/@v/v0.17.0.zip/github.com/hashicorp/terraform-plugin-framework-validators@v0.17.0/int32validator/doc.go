// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

// Package int32validator provides validators for types.Int32 attributes or function parameters.
package int32validator
