// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

// Package validatordiag provides diagnostics helpers for validator implementations.
package validatordiag
