// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

// Package float64validator provides validators for types.Float64 attributes or function parameters.
package float64validator
