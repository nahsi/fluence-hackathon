// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

// Package validatorfuncerr provides error helpers for provider-defined function validators.
package validatorfuncerr
