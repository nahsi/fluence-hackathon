// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

// Package boolvalidator provides validators for types.Bool attributes or function parameters.
package boolvalidator
