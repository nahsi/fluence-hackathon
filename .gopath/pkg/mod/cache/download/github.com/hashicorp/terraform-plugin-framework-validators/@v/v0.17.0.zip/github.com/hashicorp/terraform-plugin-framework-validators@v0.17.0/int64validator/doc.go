// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

// Package int64validator provides validators for types.Int64 attributes or function parameters.
package int64validator
