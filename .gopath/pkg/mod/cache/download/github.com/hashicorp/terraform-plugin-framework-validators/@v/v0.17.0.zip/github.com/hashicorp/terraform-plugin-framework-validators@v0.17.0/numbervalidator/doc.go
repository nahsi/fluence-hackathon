// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

// Package numbervalidator provides validators for types.Number attributes or function parameters.
package numbervalidator
