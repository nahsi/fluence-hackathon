// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

// Package mapvalidator provides validators for types.Map attributes and function parameters.
package mapvalidator
