// Package tflogtest provides functionality for unit testing of provider
// logging.
package tflogtest
