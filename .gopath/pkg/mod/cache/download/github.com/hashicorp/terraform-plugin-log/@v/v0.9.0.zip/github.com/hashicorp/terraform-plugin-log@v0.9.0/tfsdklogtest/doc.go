// Package tfsdklogtest provides functionality for unit testing of SDK
// logging. Provider developers should use the tflogtest package.
package tfsdklogtest
