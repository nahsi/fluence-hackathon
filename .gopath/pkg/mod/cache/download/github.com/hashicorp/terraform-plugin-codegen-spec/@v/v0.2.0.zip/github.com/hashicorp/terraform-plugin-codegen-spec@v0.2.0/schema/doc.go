// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

// Package schema contains types associated with generic code handling within the
// specification, such as validation.
package schema
