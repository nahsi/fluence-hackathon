// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

// Package code contains types associated with generic code handling within the
// specification, such as imports.
package code
