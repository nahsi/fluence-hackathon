// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

// Package spec contains types and functions used for parsing, and validating
// a Specification.
package spec
