# terraform-svchost

[![CI Tests](https://github.com/hashicorp/terraform-svchost/actions/workflows/ci.yml/badge.svg?branch=main)](https://github.com/hashicorp/terraform-svchost/actions/workflows/ci.yml)
[![GitHub license](https://img.shields.io/github/license/hashicorp/terraform-svchost.svg)](https://github.com/hashicorp/terraform-svchost/blob/main/LICENSE)
[![GoDoc](https://godoc.org/github.com/hashicorp/terraform-svchost?status.svg)](https://godoc.org/github.com/hashicorp/terraform-svchost)
[![Go Report Card](https://goreportcard.com/badge/github.com/hashicorp/terraform-svchost)](https://goreportcard.com/report/github.com/hashicorp/terraform-svchost)
[![GitHub issues](https://img.shields.io/github/issues/hashicorp/terraform-svchost.svg)](https://github.com/hashicorp/terraform-svchost/issues)

This package provides friendly hostnames, and is used by [terraform](https://github.com/hashicorp/terraform).
