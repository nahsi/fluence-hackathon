// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

// Package config contains the types, parsing, and validation logic for the YAML generator configuration
package config
