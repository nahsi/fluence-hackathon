// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

// Package toproto converts terraform-plugin-go tfprotov6 types to Protocol
// Buffers generated tfplugin6 types.
package toproto
