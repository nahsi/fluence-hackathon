// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

// Package funcerr contains function error helpers. These implementations are
// intentionally outside the public API.
package funcerr
