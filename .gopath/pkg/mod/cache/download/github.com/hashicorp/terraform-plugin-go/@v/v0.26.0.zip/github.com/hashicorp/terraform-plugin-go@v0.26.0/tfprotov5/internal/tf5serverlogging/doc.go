// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

// Package tf5serverlogging contains logging functionality specific to
// tf5server and tfprotov5 types.
package tf5serverlogging
