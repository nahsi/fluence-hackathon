// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

// Package fromproto converts Protocol Buffers generated tfplugin5 types into
// terraform-plugin-go tfprotov5 types.
package fromproto
