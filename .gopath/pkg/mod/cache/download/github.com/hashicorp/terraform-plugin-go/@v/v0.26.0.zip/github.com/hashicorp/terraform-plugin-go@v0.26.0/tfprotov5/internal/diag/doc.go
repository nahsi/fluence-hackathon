// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

// Package diag contains diagnostics helpers. These implementations are
// intentionally outside the public API.
package diag
