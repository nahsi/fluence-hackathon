// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

// Package logging contains shared environment variable and log functionality.
package logging
