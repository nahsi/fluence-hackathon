// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

// Package fwschemadata implements the shared schema-based data implementation
// for configuration, plan, and state values.
package fwschemadata
