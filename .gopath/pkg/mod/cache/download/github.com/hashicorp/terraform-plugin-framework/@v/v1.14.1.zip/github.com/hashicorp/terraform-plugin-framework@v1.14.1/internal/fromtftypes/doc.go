// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

// Package fromtftypes contains functions to convert from terraform-plugin-go
// tftypes types to framework types.
package fromtftypes
