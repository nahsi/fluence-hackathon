// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

// Package fwfunction contains shared interfaces and structures for implementing behaviors
// in Terraform Provider function implementations.
package fwfunction
